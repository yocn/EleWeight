package com.bjw.ComAssistant.presenter;

/**
 * Created by Yocn on 16.11.28.
 */

public class BasePresenter {
}
