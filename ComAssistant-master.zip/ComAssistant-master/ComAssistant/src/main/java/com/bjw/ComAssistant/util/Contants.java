package com.bjw.ComAssistant.util;

/**
 * Created by Yocn on 16.11.28.
 */

public class Contants {
    public static String BASE_URL = "http://www.woxian.com/";
    public static String LOGIN = "ses/user/login";
    public static String GET_LIST = "ses/order_partition/get_goods_list";
    public static String CHECK = "ses/order_partition/goods_quantity_real_config";
}
